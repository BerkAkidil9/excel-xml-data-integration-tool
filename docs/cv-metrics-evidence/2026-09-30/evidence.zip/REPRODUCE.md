# CV metriklerini yeniden ölçme

Komutları depo kökünde çalıştırın. Bu klasör 2026-09-30 çalışma kopyasının kanıtıdır; yeniden çalıştırma ham raporları yeniler. Tarihsel kanıtı korumak için önce klasörü ayrı bir yere kopyalayın veya yeni tarihli klasör kullanın. Python 3.9+ ve Java 21 gerekir. Tarihsel koşu Homebrew JDK 21.0.12 ve Maven Wrapper 3.9.11 kullandı.

## Kaynak durumunu doğrulama

Başlangıç commit'i `334f89ca0553962a7ecd5c144be5508faa581f84`. Commit tek başına yeterli değildir: iki değiştirilmiş örnek dosyanın tam kopyası `raw/baseline-examples/` altında, patch'i `raw/baseline.diff` içindedir. Tarihsel koşuyu yeni ve ayrı bir checkout'ta tekrar ediyorsanız bu iki örneği **o checkout'ın** examples dizinine kopyalayın. Mevcut kullanıcı çalışma kopyasına reset/checkout uygulamayın. Tüm izlenen kaynakların SHA-256 değerleri `environment.json` içindedir.

```sh
git rev-parse HEAD
git status --short
java -version
./mvnw -version
```

## Temiz doğrulama

```sh
./mvnw -o clean verify > docs/cv-metrics-evidence/2026-09-30/raw/clean-verify.log 2>&1
```

`-o` önceden indirilmiş bağımlılıklarla offline çalışır. Boş Maven cache için önce ağ erişimiyle bağımlılıkları edinin; cache farkını yeni manifest'e yazın. Tek koşu build süresini hızlanma metriği olarak kullanmayın. Bu incelemede üç build benchmark'ı yapılmadı.

## Coverage

JaCoCo sürümü sabit 0.8.12. Java 21 desteği [resmi değişiklik geçmişinde](https://www.jacoco.org/jacoco/trunk/doc/changes.html) 0.8.11 ile belirtilmiştir; 0.8.12 daha sonraki uyumlu sürümdür.

```sh
curl -fL https://repo.maven.apache.org/maven2/org/jacoco/org.jacoco.agent/0.8.12/org.jacoco.agent-0.8.12-runtime.jar -o /tmp/cv-jacoco-0.8.12-agent.jar
curl -fL https://repo.maven.apache.org/maven2/org/jacoco/org.jacoco.cli/0.8.12/org.jacoco.cli-0.8.12-nodeps.jar -o /tmp/cv-jacoco-0.8.12-cli.jar
python3 docs/cv-metrics-evidence/2026-09-30/scripts/coverage.py
```

İndirilen JAR hash'lerini `environment.json` ve `raw/coverage-run.json` ile karşılaştırın. Script yalnız geçici kopyadaki Surefire argLine'a agent ekler; `-Djava.awt.headless=true` korunur. Değişiklik `raw/coverage-pom.patch` içinde saklanır. Agent yalnız uygulama paketini enstrümante eder; rapor bütün `target/classes` üzerinde oluşturulur. Test sınıfları ve üçüncü taraf bağımlılıkları paydaya girmez. Ölçülemeyen/çalışmayan uygulama sınıfları dışlanmaz. Tam JaCoCo XML, CSV, execution data ve coverage koşusunun Surefire raporları korunur. Geçici kopya sonunda temizlenir.

## Benchmark

Coverage koşusunun bitmesini bekleyin; benchmark ile başka build veya CPU yoğun test çalıştırmayın.

```sh
python3 docs/cv-metrics-evidence/2026-09-30/scripts/benchmark.py > docs/cv-metrics-evidence/2026-09-30/raw/benchmark-run.log 2>&1
```

Harness production JAR'ı classpath olarak kullanır; kaynak kod değiştirmez. 6 senaryo × 3 JVM; her JVM 3 ısınma + 5 ölçüm. `-Xms512m -Xmx2g -Djava.awt.headless=true`, varsayılan GC, coverage agent yok. Her fork için 1200 saniye timeout; exit code/timeout `raw/benchmark/runs.json` içine yazılır. Fork'lar sıralıdır.

Her input 2 party, 1 hesap, 100/1000/10000 fatura ve fatura başına 5 satır içerir. Miktar 2; satır j için fiyat 10+j+0.25, vergi %20. Fatura başına net 132.50, vergi 26.50, ödenecek 159.00. Tarihler ve UTF-8 metinler deterministiktir; `.xlsx` ZIP metadata timestamp'leri nedeniyle byte hash'leri tekrarlarda farklı olabilir.

Üretim ve input doğrulaması ölçümden önce; servis kurucusu ölçümden önce bir kez çalışır. `System.nanoTime()` yalnız `convertExcelToXml` / `convertXmlToExcel` çağrısını çevreler: okuma, validation, mapping, hesaplama, dosya yazma ve geçici çıktı taşıma dahildir. JVM başlangıcı, veri üretimi ve harici çıktı kontrolü hariçtir. Disk `fsync` veya soğuk cache testi yapılmaz.

Her iterasyondan sonra servis kayıt sayıları kontrol edilir, çıktı yeniden okunur, domain record'larının bütün alanları recursive karşılaştırılır (BigDecimal scale farkı normalleştirilir). Her faturanın parasal toplamı sabit oracle ile kontrol edilir. XML çıktısında ayrıca bağımsız StAX okuması bütün serialized satır/fatura tutarlarını ve öğe sayılarını denetler. Excel calculated amount sütunu içermez; bu yönde bütün input alanlarının eşitliği ve tekrar hesaplanan toplam doğrulanır. Başarılı kontrollerden sonra CSV'ye `validated=true`, süre, dosya boyutları, çıktı SHA-256 ve batch toplamı yazılır. Hata durumunda fork nonzero çıkar; kısmi ölçümler başarılı senaryo sayılmaz.

Ham `.csv` dosyaları JVM stdout'unu olduğu gibi tutar; başlarında Log4j provider bildirimi olabilir. `benchmark_data.py` CSV başlığını bulur; ham dosyayı değiştirmez. Yalnız özeti tekrar üretmek için `python3 docs/cv-metrics-evidence/2026-09-30/scripts/benchmark.py --summarize-only` çalıştırın. İlk özetleme hatası `raw/benchmark-run.log` içinde korunmuştur; uygulama hatası değildir.

Kontroller iterasyonlar arasında ek CPU/heap/cache kullanır. Bu protokol izole mikrobenchmark veya peak throughput testi değildir. Her senaryo medyanı 15 ölçümün havuzlanmış medyanıdır; ayrıca üç fork medyanı kaydedilir. Fatura/saniye = fatura sayısı / medyan saniye. Sentetik veri alan çeşitliliği sınırlıdır ve üretimdeki fatura dağılımını temsil etmez.

## Envanter ve uzlaştırma

```sh
python3 docs/cv-metrics-evidence/2026-09-30/scripts/inventory.py
python3 docs/cv-metrics-evidence/2026-09-30/scripts/verify_evidence.py
```

`inventory.py` testlerin declaration, execution ve suite toplamlarını uzlaştırır; coverage koşusunun aynı suite'leri çalıştırdığını kontrol eder. Test kategorileri içerik incelemesine göre script'te açıkça atanmıştır; benchmark kontrolleri 103 teste katılmaz. Java package/type/import envanterleri, XLSX hücreleri, hata kodu kullanımları, XSD bildirimleri ve JAR boyutları tekrar çıkarılır. `contract-mapping.csv` XML eşlemesi, `validation-inventory.md` ve `REPORT.md` yorumları insan değerlendirmesidir; yeni sürüm için kaynakla tekrar karşılaştırılmalıdır. `verify_evidence.py` tarihsel manifest, coverage sayaçları, benchmark ham CSV'leri ve korunmuş kaynak hash'lerini kontrol eder.

## Dosyaların okunma sırası

`REPORT.md` A–H sonuç raporu ve İngilizce CV bullet'larını içerir. `validation-inventory.md` kapsam iddialarının kaynaklarını açıklar. JSON/CSV envanterleri exact sayılar içindir. `raw/` konsol çıktıları, iki ayrı Surefire koşusu, JaCoCo dosyaları, baseline farkları ve benchmark tekrarlarını içerir. `checksums.sha256` teslim edilen evidence dosyalarının bütünlük listesidir; kendisini içermez.
