import com.berk.dataintegration.domain.*;
import com.berk.dataintegration.excel.*;
import com.berk.dataintegration.xml.*;
import com.berk.dataintegration.service.*;
import com.berk.dataintegration.calculation.MoneyCalculationService;
import java.math.BigDecimal;
import java.nio.file.*;
import java.security.MessageDigest;
import java.time.LocalDate;
import java.util.*;
import javax.xml.stream.*;

/** Audit harness, deliberately outside application sources and existing test suite. */
public class ConversionBenchmark {
    static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
    static InvoiceBatch data(int count) {
        var address = new Address("Örnek Sokak", "İstanbul", "34000", "TR");
        var parties = List.of(new Party("SUP", PartyRole.SUPPLIER, "Supplier", "123", "s@example.org", "123", address),
                new Party("CUS", PartyRole.CUSTOMER, "Customer", null, null, null, address));
        var accounts = List.of(new PaymentAccount("PAY", "Supplier", "Bank", "TR0012345", "TESTTRIS", "TRY"));
        var invoices = new ArrayList<Invoice>();
        for (int i = 1; i <= count; i++) {
            var lines = new ArrayList<InvoiceLine>();
            for (int j = 1; j <= 5; j++) lines.add(new InvoiceLine(j, "ITEM-" + j, "Hizmet " + j,
                    new BigDecimal("2"), "C62", new BigDecimal((10 + j) + ".25"), new BigDecimal("20")));
            invoices.add(new Invoice("INV-" + i, LocalDate.of(2026, 1, 1), LocalDate.of(2026, 1, 31),
                    "TRY", "SUP", "CUS", "PAY", "Fatura " + i, lines));
        }
        return new InvoiceBatch(parties, accounts, invoices);
    }
    // Compare every record component, normalizing decimal scale only.
    static void same(Object expected, Object actual) throws Exception {
        if (expected instanceof BigDecimal n) {
            require(actual instanceof BigDecimal && n.compareTo((BigDecimal) actual) == 0, "decimal mismatch");
        } else if (expected instanceof List<?> list) {
            require(actual instanceof List<?> && list.size() == ((List<?>) actual).size(), "list size mismatch");
            for (int i = 0; i < list.size(); i++) same(list.get(i), ((List<?>) actual).get(i));
        } else if (expected != null && expected.getClass().isRecord()) {
            require(actual != null && actual.getClass() == expected.getClass(), "record type mismatch");
            for (var c : expected.getClass().getRecordComponents()) same(c.getAccessor().invoke(expected), c.getAccessor().invoke(actual));
        } else require(Objects.equals(expected, actual), "field mismatch: " + expected + " / " + actual);
    }
    // Independent oracle for serialized XML money; no production calculator used here.
    static void xmlMoney(Path path, int n) throws Exception {
        var f = XMLInputFactory.newFactory();
        f.setProperty(XMLInputFactory.SUPPORT_DTD, false);
        f.setProperty("javax.xml.stream.isSupportingExternalEntities", false);
        var counts = new HashMap<String, Integer>();
        var money = Map.of("TaxExclusiveAmount", "132.50", "TaxAmount", "26.50", "PayableAmount", "159.00");
        int line = 0;
        try (var input = Files.newInputStream(path)) {
            var r = f.createXMLStreamReader(input);
            while (r.hasNext()) {
                if (r.next() != XMLStreamConstants.START_ELEMENT) continue;
                String tag = r.getLocalName();
                if (tag.equals("LineNumber")) line = Integer.parseInt(r.getElementText());
                if (tag.equals("LineNetAmount") || tag.equals("LineTaxAmount") || money.containsKey(tag)) {
                    var actual = new BigDecimal(r.getElementText());
                    var expected = money.containsKey(tag) ? new BigDecimal(money.get(tag))
                            : new BigDecimal("20.50").add(new BigDecimal(2 * line));
                    if (tag.equals("LineTaxAmount")) expected = expected.multiply(new BigDecimal("0.20"));
                    require(expected.compareTo(actual) == 0, "serialized money mismatch " + tag);
                    counts.merge(tag, 1, Integer::sum);
                }
            }
            r.close();
        }
        for (String tag : money.keySet()) require(counts.getOrDefault(tag, 0) == n, "XML total count " + tag);
        for (String tag : List.of("LineNetAmount", "LineTaxAmount")) require(counts.getOrDefault(tag, 0) == 5 * n, "XML line count " + tag);
    }
    static void verify(Path path, boolean xml, InvoiceBatch expected) throws Exception {
        InvoiceBatch actual;
        if (xml) {
            var result = new XmlInvoiceReader().read(path);
            require(result.errors().isEmpty(), "XML errors: " + result.errors());
            actual = result.batch();
            xmlMoney(path, expected.invoices().size());
        } else {
            var result = new ExcelInvoiceReader().read(path);
            require(result.errors().isEmpty(), "Excel errors: " + result.errors());
            actual = result.batch();
        }
        same(expected, actual);
        var calculator = new MoneyCalculationService();
        for (var invoice : actual.invoices()) {
            var totals = calculator.calculateInvoiceTotals(invoice);
            same(new BigDecimal("132.50"), totals.taxExclusiveAmount());
            same(new BigDecimal("26.50"), totals.taxAmount());
            same(new BigDecimal("159.00"), totals.payableAmount());
        }
    }
    static String sha(Path path) throws Exception {
        var digest = MessageDigest.getInstance("SHA-256");
        try (var stream = Files.newInputStream(path)) {
            byte[] buffer = new byte[65536]; int size;
            while ((size = stream.read(buffer)) != -1) digest.update(buffer, 0, size);
        }
        return HexFormat.of().formatHex(digest.digest());
    }
    public static void main(String[] args) throws Exception {
        String direction = args[0]; int n = Integer.parseInt(args[1]); int fork = Integer.parseInt(args[2]);
        Path dir = Path.of(args[3]); Files.createDirectories(dir);
        boolean toXml = direction.equals("excel-to-xml");
        require(toXml || direction.equals("xml-to-excel"), "direction");
        var expected = data(n);
        Path input = dir.resolve(toXml ? "input.xlsx" : "input.xml");
        Path output = dir.resolve(toXml ? "output.xml" : "output.xlsx");
        if (toXml) new ExcelInvoiceWriter().write(expected, input); else new XmlInvoiceWriter().write(expected, input);
        verify(input, !toXml, expected);
        var service = new InvoiceConversionService();
        System.out.println("direction,invoices,lines,fork,phase,iteration,elapsed_ns,validated,input_bytes,output_bytes,output_sha256,payable_total");
        for (int i = 0; i < 8; i++) {
            long start = System.nanoTime();
            var result = toXml ? service.convertExcelToXml(input, output) : service.convertXmlToExcel(input, output);
            long elapsed = System.nanoTime() - start;
            require(result.isSuccess(), "conversion failed: " + result.errors());
            require(result.recordCounts().equals(new ConversionRecordCounts(2, 1, n, 5 * n)), "service counts");
            verify(output, toXml, expected);
            System.out.printf(Locale.ROOT, "%s,%d,%d,%d,%s,%d,%d,true,%d,%d,%s,%s%n", direction, n, 5*n, fork,
                    i < 3 ? "warmup" : "measure", i < 3 ? i + 1 : i - 2, elapsed,
                    Files.size(input), Files.size(output), sha(output), new BigDecimal("159.00").multiply(BigDecimal.valueOf(n)).toPlainString());
            System.out.flush();
        }
    }
}
