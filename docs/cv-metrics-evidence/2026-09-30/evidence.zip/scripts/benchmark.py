#!/usr/bin/env python3
"""Sequential, isolated JVM forks; 20-minute timeout per fork, 2 GiB max heap."""
import datetime
import json
from pathlib import Path
import statistics
import subprocess
import sys
from benchmark_data import read_rows
import tempfile

E = Path(__file__).resolve().parents[1]
ROOT = E.parents[2]
RAW = E / 'raw/benchmark'
RAW.mkdir(exist_ok=True)
JAR = ROOT / 'target/excel-xml-data-integration-tool-0.1.0-SNAPSHOT-app.jar'
if '--summarize-only' not in sys.argv:
    records = []
    with tempfile.TemporaryDirectory(prefix='cv-benchmark-') as temporary:
        work = Path(temporary)
        subprocess.run(['javac', '-cp', str(JAR), '-d', str(work), str(E / 'scripts/ConversionBenchmark.java')], check=True)
        for n in [100, 1000, 10000]:
            for direction in ['excel-to-xml', 'xml-to-excel']:
                for fork in [1, 2, 3]:
                    name = f'{direction}-{n}-{fork}'
                    command = ['java', '-Xms512m', '-Xmx2g', '-Djava.awt.headless=true', '-cp', f'{work}:{JAR}',
                               'ConversionBenchmark', direction, str(n), str(fork), str(work / name)]
                    record = {'scenario': name, 'started_at': datetime.datetime.now().astimezone().isoformat(), 'command': command}
                    with (RAW / f'{name}.csv').open('w') as out, (RAW / f'{name}.stderr').open('w') as err:
                        try:
                            result = subprocess.run(command, stdout=out, stderr=err, timeout=1200)
                            record['exit_code'] = result.returncode
                        except subprocess.TimeoutExpired:
                            record['timeout_seconds'] = 1200
                    record['finished_at'] = datetime.datetime.now().astimezone().isoformat()
                    records.append(record)
                    (RAW / 'runs.json').write_text(json.dumps(records, indent=2))
                    print(name, record.get('exit_code', 'TIMEOUT'), flush=True)
records = json.loads((RAW / 'runs.json').read_text())
summary = []
for n in [100, 1000, 10000]:
    for direction in ['excel-to-xml', 'xml-to-excel']:
        rows = []
        for fork in [1, 2, 3]:
            rows.extend(read_rows(RAW / f'{direction}-{n}-{fork}.csv'))
        measured = [r for r in rows if r['phase'] == 'measure' and r['validated'] == 'true']
        times = [int(r['elapsed_ns']) / 1e9 for r in measured]
        ok = len(rows) == 24 and len(times) == 15 and all(r.get('exit_code') == 0 for r in records if r['scenario'].startswith(f'{direction}-{n}-'))
        summary.append({'direction': direction, 'invoices': n, 'lines': n*5, 'success': ok,
                        'validated_iterations': len(rows), 'measured_iterations': len(times),
                        'median_seconds': statistics.median(times) if ok else None,
                        'min_seconds': min(times) if ok else None, 'max_seconds': max(times) if ok else None,
                        'invoices_per_second': n/statistics.median(times) if ok else None,
                        'fork_medians_seconds': {str(k): statistics.median([int(r['elapsed_ns'])/1e9 for r in measured if r['fork'] == str(k)])
                                                for k in [1,2,3] if any(r['fork'] == str(k) for r in measured)}})
(E / 'benchmark-summary.json').write_text(json.dumps(summary, indent=2))
