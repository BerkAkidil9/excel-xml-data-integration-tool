"""Read the CSV section without modifying raw JVM stdout (Log4j may prepend a notice)."""
import csv
import io

def read_rows(path):
    lines = path.read_text().splitlines()
    headers = [i for i, line in enumerate(lines) if line.startswith('direction,invoices,lines,fork,phase,')]
    if not headers:
        return []  # A failed JVM may not reach the header; runs.json preserves its exit code.
    assert len(headers) == 1, f'Unexpected repeated header: {path}'
    rows = list(csv.DictReader(io.StringIO('\n'.join(lines[headers[0]:]))))
    assert all(None not in row and all(v is not None for v in row.values()) for row in rows), path
    return rows
