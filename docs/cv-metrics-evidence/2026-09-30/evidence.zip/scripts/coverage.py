#!/usr/bin/env python3
"""Run only the existing suite in a temporary source copy, with JaCoCo 0.8.12."""
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile

EVIDENCE = Path(__file__).resolve().parents[1]
ROOT = EVIDENCE.parents[2]
AGENT = Path('/tmp/cv-jacoco-0.8.12-agent.jar')
CLI = Path('/tmp/cv-jacoco-0.8.12-cli.jar')
RAW = EVIDENCE / 'raw'

with tempfile.TemporaryDirectory(prefix='cv-coverage-') as directory:
    copy = Path(directory)
    for name in ['src', 'examples', 'templates', '.mvn']:
        shutil.copytree(ROOT / name, copy / name)
    shutil.copy2(ROOT / 'mvnw', copy / 'mvnw')
    original = (ROOT / 'pom.xml').read_text()
    modified = original.replace('<argLine>-Djava.awt.headless=true</argLine>',
        f'<argLine>-Djava.awt.headless=true -javaagent:{AGENT}=destfile={copy}/target/jacoco.exec,includes=com.berk.dataintegration.*</argLine>')
    assert modified != original
    (copy / 'pom.xml').write_text(modified)
    (RAW / 'coverage-pom.patch').write_text(''.join(difflib.unified_diff(
        original.splitlines(True), modified.splitlines(True), fromfile='original/pom.xml', tofile='temporary/pom.xml')))
    commands = [
        ['./mvnw', '-o', 'clean', 'verify'],
        ['java', '-jar', str(CLI), 'report', str(copy / 'target/jacoco.exec'),
         '--classfiles', str(copy / 'target/classes'), '--sourcefiles', str(copy / 'src/main/java'),
         '--xml', str(RAW / 'jacoco.xml'), '--csv', str(RAW / 'jacoco.csv')],
    ]
    for index, command in enumerate(commands):
        with (RAW / f'coverage-{index}.log').open('w') as log:
            subprocess.run(command, cwd=copy, stdout=log, stderr=subprocess.STDOUT, check=True)
    shutil.copy2(copy / 'target/jacoco.exec', RAW / 'jacoco.exec')
    shutil.copytree(copy / 'target/surefire-reports', RAW / 'coverage-surefire', dirs_exist_ok=True)
    (RAW / 'coverage-run.json').write_text(json.dumps({
        'version': '0.8.12', 'commands': commands,
        'jar_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in [AGENT, CLI]},
        'source_sha256': {str(p.relative_to(copy)): hashlib.sha256(p.read_bytes()).hexdigest()
                          for p in sorted((copy / 'src').rglob('*')) if p.is_file()},
    }, indent=2))
