#!/usr/bin/env python3
"""Reconcile source declarations, Surefire executions, coverage and file contracts."""
import collections
import csv
import hashlib
import json
from pathlib import Path
import re
import shutil
import xml.etree.ElementTree as ET
import zipfile

E = Path(__file__).resolve().parents[1]
R = E.parents[2]
def save(name, value):
    (E / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
def table(name, rows):
    with (E / name).open('w') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
def loc(path, pattern):
    return next(i for i, line in enumerate(path.read_text().splitlines(), 1) if pattern in line)

sources = []
for path in sorted((R / 'src').rglob('*.java')):
    text = path.read_text(); lines = text.splitlines()
    sources.append({'path': str(path.relative_to(R)), 'package': re.search(r'package (.*?);', text)[1],
                    'lines': len(lines), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                    'types': [{'line': i, 'declaration': s.strip()} for i, s in enumerate(lines, 1)
                              if re.search(r'\b(class|record|interface|enum) \w+', s)],
                    'imports': [s for s in lines if s.startswith('import ')]})
save('source-inventory.json', sources)
packages = collections.defaultdict(list)
for row in sources:
    if row['path'].startswith('src/main/'):
        packages[row['package']].append(row['path'])
save('package-inventory.json', dict(packages))

shutil.copytree(R / 'target/surefire-reports', E / 'raw/surefire', dirs_exist_ok=True)
test_rows = []
suites = []
for path in sorted((E / 'raw/surefire').glob('TEST-*.xml')):
    suite = ET.parse(path).getroot()
    suites.append({k: suite.get(k) for k in ['name', 'tests', 'failures', 'errors', 'skipped', 'time']})
    for case in suite.findall('testcase'):
        name = case.get('name'); cls = case.get('classname'); short = cls.rsplit('.', 1)[1]
        source = R / 'src/test/java' / (cls.replace('.', '/') + '.java')
        category, reason = 'unit', 'In-memory logic/state; collaborators may be stubbed.'
        if '.excel.' in cls or '.xml.' in cls or short in ['ConversionErrorReportWriterTest', 'NavigationFileChooserTest', 'SwingWorkerConversionExecutorTest']:
            category, reason = 'component', 'File-format/file-system or Swing component exercised with real implementation.'
        if short == 'InvoiceConversionServiceTest' or (short == 'ConversionControllerTest' and name in ['savesCurrentErrorsAsCsvReport', 'savesExcelTemplate']):
            category, reason = 'integration', 'Coordinates multiple real application components and file I/O.'
        if short == 'CommandLineAppTest':
            category, reason = 'component', 'CLI argument/output boundary; help or usage path.'
            if name in ['convertsExcelToXmlAndPrintsSuccessSummary', 'returnsConversionFailureForInvalidInputAndDoesNotWriteOutput', 'writesExcelTemplate']:
                category, reason = 'application-workflow', 'In-process CLI run to real files; does not launch main/JAR or display a window.'
        test_rows.append({'class': cls, 'method': name, 'source': str(source.relative_to(R)),
                          'line': loc(source, 'void ' + name + '('), 'category': category, 'reason': reason,
                          'tags': ';'.join(t for t, yes in [('UI', '.ui.' in cls), ('security', 'Xxe' in name)] if yes),
                          'status': 'failure' if case.find('failure') is not None else 'error' if case.find('error') is not None else 'skipped' if case.find('skipped') is not None else 'passed'})
table('test-inventory.csv', test_rows)
declared = sum(len(re.findall(r'@Test\b', p.read_text())) for p in (R / 'src/test/java').rglob('*.java'))
assert declared == len(test_rows) == sum(int(s['tests']) for s in suites)
assert len({(r['class'], r['method']) for r in test_rows}) == len(test_rows)
summary = {'declarations_Test': declared, 'suites': len(suites), 'executed': len(test_rows),
           'passed': sum(r['status'] == 'passed' for r in test_rows),
           'failures': sum(int(s['failures']) for s in suites),
           'errors': sum(int(s['errors']) for s in suites),
           'skipped': sum(int(s['skipped']) for s in suites),
           'status_counts': dict(collections.Counter(r['status'] for r in test_rows)),
           'categories': dict(collections.Counter(r['category'] for r in test_rows)), 'suite_details': suites}
save('test-summary.json', summary)
coverage_suites = [ET.parse(p).getroot() for p in (E / 'raw/coverage-surefire').glob('TEST-*.xml')]
assert {(s.get('name'), s.get('tests'), s.get('failures'), s.get('errors'), s.get('skipped')) for s in coverage_suites} == {
    (s['name'], s['tests'], s['failures'], s['errors'], s['skipped']) for s in suites}
def counters(node):
    return {c.get('type'): {'covered': int(c.get('covered')), 'missed': int(c.get('missed')),
                          'total': int(c.get('covered')) + int(c.get('missed')),
                          'percent': 100*int(c.get('covered'))/(int(c.get('covered'))+int(c.get('missed')))}
            for c in node.findall('counter') if int(c.get('covered'))+int(c.get('missed'))}
coverage = ET.parse(E / 'raw/jacoco.xml').getroot()
cov = {'all_application': counters(coverage), 'packages': {p.get('name'): counters(p) for p in coverage.findall('package')},
       'classes': {c.get('name'): counters(c) for p in coverage.findall('package') for c in p.findall('class')}}
core_names = ['domain', 'calculation', 'validation', 'excel', 'xml', 'xml/dto', 'service']
core = collections.defaultdict(lambda: {'covered': 0, 'missed': 0})
for p, values in cov['packages'].items():
    if p.removeprefix('com/berk/dataintegration/') in core_names:
        for kind, value in values.items():
            for k in ['covered', 'missed']: core[kind][k] += value[k]
for v in core.values():
    v['total'] = v['covered'] + v['missed']; v['percent'] = 100*v['covered']/v['total']
cov['core_packages'] = core_names; cov['core'] = dict(core)
save('coverage-summary.json', cov)

definition = R / 'src/main/java/com/berk/dataintegration/excel/ExcelSheetDefinition.java'
sheet = None; columns = []
for i, line in enumerate(definition.read_text().splitlines(), 1):
    m = re.search(r'\w+\("(\w+)", List.of', line)
    if m: sheet = m[1]
    m = re.search(r'new ExcelColumn\("([^"]+)", "([^"]+)", ExcelCellKind.(\w+)\)', line)
    if m: columns.append({'sheet': sheet, 'header': m[1], 'domain_field': m[2], 'kind': m[3], 'source': str(definition.relative_to(R)), 'line': i})
table('excel-columns.csv', columns)
ns = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
workbooks = []
for folder in ['examples', 'templates', 'src/test/resources']:
    for path in sorted((R / folder).rglob('*.xlsx')):
        with zipfile.ZipFile(path) as z:
            strings = []
            if 'xl/sharedStrings.xml' in z.namelist():
                strings = [''.join(n.itertext()) for n in ET.fromstring(z.read('xl/sharedStrings.xml'))]
            book = ET.fromstring(z.read('xl/workbook.xml'))
            rels = {n.get('Id'): n.get('Target') for n in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
            sheets = []
            for s in book.findall('s:sheets/s:sheet', ns):
                target = rels[s.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')]
                target = target.lstrip('/') if target.startswith('/') else 'xl/' + target
                rows = []
                for row in ET.fromstring(z.read(target)).findall('s:sheetData/s:row', ns):
                    cells = []
                    for c in row.findall('s:c', ns):
                        value = c.findtext('s:v', default='', namespaces=ns)
                        if c.get('t') == 's': value = strings[int(value)]
                        if c.get('t') == 'inlineStr': value = ''.join(c.find('s:is', ns).itertext())
                        cells.append({'cell': c.get('r'), 'type': c.get('t', 'n'), 'value': value})
                    rows.append({'row': row.get('r'), 'cells': cells})
                sheets.append({'name': s.get('name'), 'rows': rows})
            workbooks.append({'path': str(path.relative_to(R)), 'sheets': sheets})
save('workbook-inventory.json', workbooks)

codes_path = R / 'src/main/java/com/berk/dataintegration/validation/ValidationCode.java'
codes = []
for i, line in enumerate(codes_path.read_text().splitlines(), 1):
    m = re.fullmatch(r'\s+([A-Z][A-Z_]+),?\s*', line)
    if m:
        uses = []
        for p in sorted((R / 'src/main/java').rglob('*.java')):
            for j, s in enumerate(p.read_text().splitlines(), 1):
                if 'ValidationCode.' + m[1] in s: uses.append({'path': str(p.relative_to(R)), 'line': j, 'text': s.strip()})
        codes.append({'name': m[1], 'declaration_line': i, 'uses': uses})
save('validation-codes.json', codes)
xsd = R / 'src/main/resources/schema/invoice-data-v1.xsd'
save('xsd-inventory.json', [{'line': i, 'text': s.strip()} for i, s in enumerate(xsd.read_text().splitlines(), 1) if '<xs:' in s])
save('artifact-sizes.json', [{'path': str(p.relative_to(R)), 'bytes': p.stat().st_size,
                             'MiB': p.stat().st_size / 1048576, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
                            for p in sorted((R / 'target').glob('*.jar'))])
save('inventory-summary.json', {'main_java_files_including_package_info': sum(len(v) for v in packages.values()),
                              'packages': len(packages), 'test_java_files_including_helper': sum(s['path'].startswith('src/test/') for s in sources),
                              'columns': dict(collections.Counter(c['sheet'] for c in columns)), 'validation_codes': len(codes),
                              'maven_projects': 1, 'child_maven_modules': 0})
print(json.dumps(summary | {'suite_details': 'see test-summary.json'}, indent=2))
