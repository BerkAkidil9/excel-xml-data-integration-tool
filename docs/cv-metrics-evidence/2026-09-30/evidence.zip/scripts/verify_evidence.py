#!/usr/bin/env python3
"""Evidence consistency checks, separate from the application's 103 JUnit tests."""
import collections
import csv
import datetime
import hashlib
import json
from pathlib import Path
import statistics
import subprocess
import xml.etree.ElementTree as ET
from benchmark_data import read_rows

E = Path(__file__).resolve().parents[1]
R = E.parents[2]
manifest = json.loads((E / 'environment.json').read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip() == manifest['commit']['output'].strip()
for name, metadata in manifest['tracked_files'].items():
    assert hashlib.sha256((R / name).read_bytes()).hexdigest() == metadata['sha256'], f'Source changed: {name}'
coverage_run = json.loads((E / 'raw/coverage-run.json').read_text())
for name, digest in coverage_run['source_sha256'].items():
    assert digest == manifest['tracked_files'][name]['sha256'], name
suite_sets = []
for folder in ['surefire', 'coverage-surefire']:
    suites = [ET.parse(p).getroot() for p in (E / 'raw' / folder).glob('TEST-*.xml')]
    assert len(suites) == 21
    assert sum(int(s.get('tests')) for s in suites) == 103
    assert all(int(s.get(k)) == 0 for s in suites for k in ['errors', 'failures', 'skipped'])
    suite_sets.append({(c.get('classname'), c.get('name')) for s in suites for c in s.findall('testcase')})
assert suite_sets[0] == suite_sets[1]
with (E / 'test-inventory.csv').open() as f: tests = list(csv.DictReader(f))
assert len(tests) == 103 and {(r['class'], r['method']) for r in tests} == suite_sets[0]
assert sum(collections.Counter(t['category'] for t in tests).values()) == 103
coverage = ET.parse(E / 'raw/jacoco.xml').getroot()
summary = json.loads((E / 'coverage-summary.json').read_text())
for counter in coverage.findall('counter'):
    kind = counter.get('type')
    for key in ['covered', 'missed']:
        value = int(counter.get(key))
        assert value == summary['all_application'][kind][key]
        assert value == sum(int(p.find(f"counter[@type='{kind}']").get(key)) for p in coverage.findall('package') if p.find(f"counter[@type='{kind}']") is not None)
    total = sum(int(counter.get(k)) for k in ['covered', 'missed'])
    assert total == summary['all_application'][kind]['total']
    assert abs(summary['all_application'][kind]['percent'] - 100*int(counter.get('covered'))/total) < 1e-10
runs = json.loads((E / 'raw/benchmark/runs.json').read_text())
assert len(runs) == 18 and all(r.get('exit_code') == 0 for r in runs)
bench = json.loads((E / 'benchmark-summary.json').read_text())
assert len(bench) == 6
for s in bench:
    rows = []
    n = s['invoices']
    for fork in [1, 2, 3]:
        fork_rows = read_rows(E / f"raw/benchmark/{s['direction']}-{n}-{fork}.csv")
        assert len(fork_rows) == 8
        assert [r['phase'] for r in fork_rows] == ['warmup']*3 + ['measure']*5
        assert [r['iteration'] for r in fork_rows] == ['1','2','3','1','2','3','4','5']
        assert all(r['fork'] == str(fork) for r in fork_rows)
        rows += fork_rows
    assert all(r['direction'] == s['direction'] and int(r['invoices']) == n and int(r['lines']) == 5*n
               and r['validated'] == 'true' and int(r['elapsed_ns']) > 0 and len(r['output_sha256']) == 64
               and r['payable_total'] == f'{159*n}.00' for r in rows)
    values = [int(r['elapsed_ns'])/1e9 for r in rows if r['phase'] == 'measure']
    assert s['success'] and s['measured_iterations'] == len(values) == 15 and s['validated_iterations'] == len(rows) == 24
    assert s['median_seconds'] == statistics.median(values)
    assert s['min_seconds'] == min(values) and s['max_seconds'] == max(values)
    assert abs(s['invoices_per_second'] - n/statistics.median(values)) < 1e-9
with (E / 'excel-columns.csv').open() as f: columns = list(csv.DictReader(f))
assert len(columns) == 32 and collections.Counter(c['sheet'] for c in columns) == {'Parties': 10, 'PaymentAccounts': 6, 'Invoices': 8, 'InvoiceLines': 8}
for artifact in json.loads((E / 'artifact-sizes.json').read_text()):
    path = R / artifact['path']
    assert path.stat().st_size == artifact['bytes'] and hashlib.sha256(path.read_bytes()).hexdigest() == artifact['sha256']
result = {'verified_at': datetime.datetime.now().astimezone().isoformat(), 'tracked_files_unchanged': len(manifest['tracked_files']),
          'baseline_tests_passed': 103, 'coverage_tests_passed': 103, 'benchmark_jvm_successes': 18,
          'validated_benchmark_iterations': 144, 'measured_benchmark_iterations': 90,
          'test_categories': dict(collections.Counter(t['category'] for t in tests)),
          'status': 'all evidence assertions passed', 'scope': 'Audit checks, not additional application JUnit tests'}
(E / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
